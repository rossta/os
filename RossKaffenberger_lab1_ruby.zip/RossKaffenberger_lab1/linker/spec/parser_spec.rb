require File.dirname(__FILE__) + '/spec_helper'

describe Parser do
  describe "skip_whitespace" do
    it "should description" do
      
    end
  end
end
