require File.dirname(__FILE__) + '/../../shared/lib/env'
Dir.glob(File.join(File.dirname(__FILE__), '/*.rb')).each {|f| require f }
