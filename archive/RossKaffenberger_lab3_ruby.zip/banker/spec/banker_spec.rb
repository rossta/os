require File.dirname(__FILE__) + '/spec_helper'

describe Banker do
  it "should description" do
    
  end
end
