class InstructionType
  I = "I"
  R = "R"
  E = "E"
  A = "A"
end