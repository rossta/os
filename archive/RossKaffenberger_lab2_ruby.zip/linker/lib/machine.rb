class Machine
  SIZE = 600
end