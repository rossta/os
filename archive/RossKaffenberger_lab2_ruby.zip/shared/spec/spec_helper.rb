require File.dirname(__FILE__) + '/../../rspec/spec/spec_helper'
require File.dirname(__FILE__) + '/../lib/env'
