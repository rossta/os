package lib;

/**
 * User: Ross Kaffenberger
 * Date: Sep 24, 2009
 * Time: 1:58:08 AM
 */
public class Machine {
    public static final int SIZE = 600;
}
