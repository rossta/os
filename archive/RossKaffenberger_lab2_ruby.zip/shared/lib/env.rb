Dir.glob(File.join(File.dirname(__FILE__), '/*.rb')).each {|f| require f }
# Dir.glob(File.join(File.dirname(__FILE__), '/*/*.rb')).each {|f| puts f; require f }
